#!/bin/bash

cd Game; ./main.py $1
