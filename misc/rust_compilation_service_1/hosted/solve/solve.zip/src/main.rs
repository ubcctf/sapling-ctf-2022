fn main() {
    // just include_str lul
    println!("{}", include_str!("/chal/flag.txt"));
}