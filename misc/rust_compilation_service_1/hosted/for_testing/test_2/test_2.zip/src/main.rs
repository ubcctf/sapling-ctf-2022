fn not_main() {
    println!("Hello, world! {}", unbound);
}
